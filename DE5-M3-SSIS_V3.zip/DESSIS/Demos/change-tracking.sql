/*
QASQLETL Module 6 Demo on the Change Tracking
*/

-- Step 1: Create CustomerCT database
--
USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerCT')
begin
	ALTER DATABASE CustomerCT SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP database CustomerCT;
end

CREATE Database CustomerCT;
GO
 
-- Step 2: Create the Customers and ExtractLog tables
--
USE CustomerCT;
go

CREATE TABLE dbo.Customers
(CustomerID int identity primary key,
 CustName   varchar(50),
 City       varchar(50),
 Country    varchar(50)
)
go

CREATE TABLE dbo.ExtractLog
(SourceName           varchar(20),
 LastExtractTime      datetime,
 LastExtractedVersion int
)
GO

-- Step 3: Insert data into the Customers and ExtractLog tables
--
INSERT INTO Customers
 (CustName,City,Country)
VALUES
 ('Fred','London','UK'),
 ('Lily','Denver','US'),
 ('Reza','Bristol','UK')
GO

INSERT INTO dbo.ExtractLog
VALUES
 ('Customers', dateadd(DAY, -1, getdate()), 0);
GO

select * from dbo.Customers;
select * from dbo.ExtractLog;

-- Step 4: Enable Change Tracking
--
USE master
GO

ALTER DATABASE CustomerCT
SET CHANGE_TRACKING = ON
  (CHANGE_RETENTION = 7 DAYS, AUTO_CLEANUP = ON)
GO

ALTER DATABASE CustomerCT
SET ALLOW_SNAPSHOT_ISOLATION ON
GO

USE CustomerCT
GO

ALTER TABLE dbo.Customers
ENABLE CHANGE_TRACKING
WITH (TRACK_COLUMNS_UPDATED = ON)
GO

-- Step 5: Obtain the initial data and log the current version number
--
DECLARE @current_version BigInt
SET @current_version = CHANGE_TRACKING_CURRENT_VERSION();

UPDATE dbo.ExtractLog
SET LastExtractedVersion = @current_version
WHERE SourceName = 'Customers';

select * from dbo.ExtractLog;

-- Step 6: Insert a new Customer
--
INSERT INTO Customers
 (CustName,city,country)
VALUES
 ('Dinah','Talinn','EE')
GO

-- Step 7: Update a Customer
--
UPDATE dbo.Customers
	SET city = 'Paris',
	Country='FR'
WHERE CustomerID = 1
GO

Select * from dbo.Customers;


-- Step 8: Retrieve the changes between the last extracted and current versions
--
SET TRANSACTION ISOLATION LEVEL SNAPSHOT

DECLARE @previous_version BigInt
SELECT @previous_version = MAX(LastExtractedVersion)
FROM dbo.ExtractLog
WHERE SourceName = 'Customers';

DECLARE @current_version BigInt
SET @current_version = CHANGE_TRACKING_CURRENT_VERSION();
print @current_version;

SELECT  @previous_version 'Previously retrieved Version',
	    @current_version 'Current version',
		CT.CustomerID,
        C.Custname,
		C.City,
		C.Country
FROM
CHANGETABLE(CHANGES dbo.Customers, @previous_version) as CT
INNER JOIN dbo.Customers as C ON CT.CustomerID = C.CustomerID;

UPDATE dbo.ExtractLog
SET LastExtractedVersion = @current_version
WHERE SourceName = 'Customers';

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

select * from dbo.ExtractLog;

-- END of Script