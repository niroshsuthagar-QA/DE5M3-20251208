/*
QASQLETL Demo on partioning
*/

-- Step 1: Create CustomerPAR database
--
USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerPAR')
begin
	ALTER DATABASE CustomerPAR SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database  CustomerPAR;
end
GO

CREATE  Database CustomerPAR
GO

-- Step 2: Add additional filegroups
--
ALTER DATABASE CustomerPAR ADD FILEGROUP F1
GO
ALTER DATABASE CustomerPAR ADD FILEGROUP F2
GO
ALTER DATABASE CustomerPAR ADD FILEGROUP F3
GO

-- Step 3:  Create additional files to the filegroups
--
ALTER DATABASE CustomerPAR
	ADD FILE 
	(
		NAME = 'Partition1',
		FILENAME = 'C:\SQLETLDB\customerPAR1.ndf'
	)
	TO FILEGROUP F1
GO

ALTER DATABASE CustomerPAR
	ADD FILE 
	(
		NAME = 'Partition2',
		FILENAME = 'C:\SQLETLDB\customerPAR2.ndf'
	)
	TO FILEGROUP F2
GO

ALTER DATABASE CustomerPAR
	ADD FILE 
	(
		NAME = 'Partition3',
		FILENAME = 'C:\SQLETLDB\customerPAR3.ndf'
	)
	TO FILEGROUP F3
GO

-- Step 4:  Examine the database structure
--
USE CustomerPAR
GO

select fg.name,fg.type, f.file_id, f.name, f.physical_name 
FROM sys.filegroups as fg LEFT JOIN sys.database_files as f
ON fg.data_space_id = f.data_space_id;

-- Confirm that the files have been created on the C: drive

-- Step 5:  Create a partition function
/*
Data with dates less than 20230101 will go into the first partition.
Data with dates from 20230101 to 20231231 23:59:59 will go into the second partition.
Data from 20240101 onward will go into the third partition.
*/
CREATE PARTITION FUNCTION DatePartitioningFunction(datetime)
	AS RANGE RIGHT FOR VALUES ('20230101','20240101')
GO

-- Step 6: Create a partition scheme
--
CREATE PARTITION SCHEME DatePartitionScheme
	AS PARTITION DatePartitioningFunction
	TO (F1,F2,F3)
GO

-- Step 7:  Create a table using the partitioning
--
CREATE TABLE dbo.Sales (
 SalesID int ,
 CustomerName varchar(50),
 OrderDate datetime
)
ON DatePartitionScheme(OrderDate)
GO

-- Step 8:  Add some data
--
SET NOCOUNT ON;
DECLARE @val INT
SELECT @val=1
WHILE @val < 1000
BEGIN  
   INSERT INTO dbo.Sales(SalesID,CustomerName,OrderDate) 
      VALUES (@val,'Customer ' + cast(@val as varchar),getdate()-@val)
   SELECT @val=@val+1
END
GO
SET NOCOUNT OFF;

select count(*) from dbo.Sales;

select * from dbo.Sales
order by SalesID;

-- Step 9: Examine how the table has been partitioned
--
SELECT o.name as [Table Name], p.partition_number,p.rows
FROM sys.partitions p
INNER JOIN sys.objects o ON o.object_id=p.object_id
WHERE o.name = 'Sales';

/*
Partition 1 < 188 rows ~ dates before  01/01/2023
Partition 2 = 365 rows ~ dates between 01/01/2023 and 31/12/2023
Partition 3 > 446 rows ~ dates after   01/01/2024
*/

-- END of Script