/*
QASQLETL Module 6 Demo on Temporal tables
*/

-- Step 1: Create CustomerTT database
--
USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerTT')
begin
	ALTER DATABASE CustomerTT SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP database  CustomerTT;
end

CREATE  Database CustomerTT
GO
 
-- Step 2: Create the Customers temporal table
--
USE CustomerTT
go

CREATE TABLE dbo.Customers
(
CustomerID   int identity primary key,
CustName     varchar(50),
City         varchar(50),
Country      varchar(50),
SysStartTime datetime2 GENERATED ALWAYS AS ROW START NOT NULL,
SysEndTime   datetime2 GENERATED ALWAYS AS ROW END NOT NULL,
PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime)
) WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.CustomerHistory))
go

-- Step 3: Insert data into the Customers table
--
INSERT INTO Customers
 (CustName,city,country)
VALUES
 ('Fred','London','UK'),
 ('Lily','Denver','US'),
 ('Reza','Bristol','UK')
GO

-- Step 4: Query the Customers and CustomerHistory tables
--
select * from dbo.Customers;
select * from dbo.CustomerHistory;  -- notice this is empty at the moment

-- Step 5: make some changes to the customer table
--
UPDATE dbo.Customers
  SET City = 'Paris',
      Country='FR'
WHERE CustomerID = 1;

DELETE dbo.Customers WHERE CustomerID = 2;
GO

-- Step 6: Query the customers and customerHistory tables
--
select * from dbo.Customers;
select * from dbo.CustomerHistory;  -- notice this now contains the old versions

-- Step 7: Query customers at a point in time. View the result in Object Explorer.
--
select * from dbo.Customers
FOR SYSTEM_TIME ALL;

-- Step 8: Make some more changes
--
UPDATE dbo.Customers
	SET city = 'Cardiff'
	WHERE CustomerID = 3;

-- Step 9: Query the customers and customerHistory tables
--
select * from dbo.Customers;
select * from dbo.CustomerHistory;

-- Step 10: Make another change
--
UPDATE dbo.Customers
	SET city = 'Glasgow'
	WHERE CustomerID = 3;

-- Step  11: Query the customers and customerHistory tables
--
select * from dbo.Customers;
select * from dbo.CustomerHistory;

-- Make a note of the SysEndTime values of the deletion of Customerid 2
--  and the 1st change of customerid 3
select 'Deletion of CustomerID 2', SysEndTime from dbo.CustomerHistory where CustomerID = 2
union
select 'First change of CustomerID 3', min(SysEndTime) from dbo.CustomerHistory where CustomerID = 3;

--  Step 12: Query customers between 2 points in time 
--
select * from dbo.Customers
FOR SYSTEM_TIME 
BETWEEN '2025-03-22 13:47:01' and '2025-03-22 13:48:23'
--change times to the ones recorded in step 11.
GO

-- Step 13: Turn off versioning
--
ALTER TABLE dbo.Customers SET (SYSTEM_VERSIONING = OFF)
GO

-- Refresh Object Explorer.  Notice that CustomerHistory is now a seperate table.

-- Step 14: Empty dbo.CustomersHistory
--
TRUNCATE TABLE dbo.CustomerHistory
GO

-- Step 15: Re-enable versioning
--
ALTER TABLE dbo.Customers
SET (SYSTEM_VERSIONING = ON
 (HISTORY_TABLE = dbo.CustomerHistory,DATA_CONSISTENCY_CHECK=ON)
);

-- Refresh Object Explorer and see the result.

-- Result: We are back to one table again with CustomerHistory as a history table

-- End of Script