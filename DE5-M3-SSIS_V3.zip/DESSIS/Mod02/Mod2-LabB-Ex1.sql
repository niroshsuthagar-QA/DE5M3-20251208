/*
QASQLETL Module 2 Lab B
Exercise 01 - Create the database and partitioning
*/

-- Step 1: Create the QASQLETLDW database
USE MASTER;

if EXISTS (select * from sys.databases where name = 'QASQLETLDW') -- Drop the database if it already exists.
begin
	ALTER DATABASE QASQLETLDW SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database QASQLETLDW;
end
GO

CREATE DATABASE QASQLETLDW ON PRIMARY
	(
	NAME = 'QASQLETLDW_Data',
	FILENAME = 'C:\SQLETLDB\QASQLETLDW_Data.mdf',
	SIZE = 40Mb,
	MAXSIZE = 100Mb,
	FILEGROWTH = 20Mb
	)
LOG ON
	(
	NAME = 'QASQLETLDW_Log',
	FILENAME = 'C:\SQLETLLogs\QASQLETLDW_Log.ldf',
	SIZE = 5Mb,
	MAXSIZE = 30Mb,
	FILEGROWTH = 5Mb
	);	
GO

-- Step 2: Create additional filegroups for the dimensions tables and the fact table


ALTER DATABASE QASQLETLDW
	ADD FILEGROUP Dimensions;
GO

ALTER DATABASE QASQLETLDW
	ADD FILEGROUP Facts2020Before;
GO

ALTER DATABASE QASQLETLDW
	ADD FILEGROUP Facts2021;
GO

ALTER DATABASE QASQLETLDW
	ADD FILEGROUP Facts2022;
GO


-- Step 3:  Create additional files to the filegroups

ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'DIMFile',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWDim.ndf',
	SIZE = 10mb,
	MAXSIZE = 20mb,
	FILEGROWTH = 5mb
	)
	TO FILEGROUP Dimensions;
GO

ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'Fact2020File',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWFact2020.ndf',
	SIZE = 100mb,
	MAXSIZE = 200mb,
	FILEGROWTH = 50mb
	)
	TO FILEGROUP Facts2020Before;
GO

ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'Fact2021File',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWFact2021.ndf',
	SIZE = 100mb,
	MAXSIZE = 200mb,
	FILEGROWTH = 50mb
	)
	TO FILEGROUP Facts2021;
GO

ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'Fact2022File',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWFact2022.ndf',
	SIZE = 100mb,
	MAXSIZE = 200mb,
	FILEGROWTH = 50mb
	)
	TO FILEGROUP Facts2022;
go
