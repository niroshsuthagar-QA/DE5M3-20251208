/*
QASQLETL Module 2 Lab B
Exercise 02 - Create the database and partitioning
*/

-- Step 1: Create a partition function to split dates based on the values 20210101 and 20220101

use QASQLETLDW;

CREATE PARTITION FUNCTION DatePartitioningFunction(char(8))
	AS RANGE RIGHT FOR VALUES ('20210101','20220101')
GO

/*Step 2:	Create a partition scheme to use the partition 
			function DatePartitioningFunction and 
			split the tables over the filegroups previously
			created Facts2020Before,Facts2021,Facts2022
*/

CREATE PARTITION SCHEME DatePartitionScheme
	AS PARTITION DatePartitioningFunction
	TO (Facts2020Before,Facts2021,Facts2022)
GO
