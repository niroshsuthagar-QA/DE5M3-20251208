/*
QASQLETL Module 2 Lab C
Exercise 01 - Create the fact tables
*/

USE QASQLETLDW;

-- Step 1: Create a FactInternetSales table

CREATE TABLE FactInternetSales(
	SalesOrderdetailID int not null,
	SalesOrderID int not null,
	SKDateOrderDate char(8),
	SKDateDueDate char(8),
	SKDateShipDate char(8),
	SKCustomer int,
	SKProduct int,
	OrderQuantity bigint,
	SalesAmount money
) ON DatePartitionScheme(SKDateOrderDate);
GO

-- Step 2: Create a FactResellerSales table

CREATE TABLE FactResellerSales(
	SalesOrderdetailID int not null,
	SalesOrderID int not null,
	SKDateOrderDate char(8),
	SKDateDueDate char(8),
	SKDateShipDate char(8),
	SKReseller int,
	SKProduct int,
	OrderQuantity bigint,
	SalesAmount money
) ON DatePartitionScheme(SKDateOrderDate);
GO
