/*
QASQLETL Module 2 Lab D
Exercise 01 - Create the dimension tables
*/

-- Step 1: Create the DimProduct table 

USE QASQLETLDW;
GO

CREATE TABLE DimProduct(
	SKProduct int identity(1,1) primary key,
	ProductBusinessKey int not null,
	ProductName nvarchar(50),
	SubcategoryName nvarchar(50),
	CategoryName nvarchar(50),
	Colour nvarchar(15),
	Style nchar(2),
	Size nvarchar(5),
	ProductLine nchar(2),
	SCDValidFrom datetime default getdate(),
	SCDValidTo datetime default null
) ON Dimensions
GO

-- Step 2: Create the DimGeography table 

CREATE TABLE DimGeography(
	SKGeography int identity(1,1) primary key,
	StateProvinceID int not null,
	City nvarchar(30) not null,
	StateProvinceName nvarchar(50),
	TerritoryName nvarchar(50),
	RegionName nvarchar(50)
) ON Dimensions
GO

-- Step 3: Create the DimCustomer table

CREATE TABLE DimCustomer(
	SKCustomer int identity(1,1) primary key,
	CustomerBusinessKey int not null,
	Title nvarchar(8),
	FirstName nvarchar(50),
	MiddleName nvarchar(50),
	LastName nvarchar(50),
	SKGeography int
) ON Dimensions
GO

-- Step 4:	Create the DimReseller table. 
--			The table has a relationship to the conformed dimension DimGeography.

CREATE TABLE DimReseller(
	SKReseller int identity(1,1) primary key,
	ResellerBusinessKey int not null,
	ResellerName  nvarchar(50),
	ResellerAddress  nvarchar(120),
	SKGeography int
) ON Dimensions
GO
