/*
QASQLETL Module 2 Lab D
Exercise 02 - Create the date dimension table
*/

--  Step 1: Create the DimDate table 

USE QASQLETLDW;
GO

CREATE TABLE DimDate(
	SKDate char(8) primary key,
	RealDate date,
	CalendarYear int,
	CalendarQuarter int,
	CalendarMonth int,
	MonthTitle nvarchar(20),
	FiscalYear varchar(20),
	FiscalQuarter int
) ON Dimensions
GO

-- Step 2: Insert rows into the DimTime table

SET NOCOUNT ON
DECLARE @StartDate date, @EndDate date, @D date
DECLARE @DateKey char(10)
SET @StartDate = '2006-01-01'
SET @EndDate = '2025-12-31'
SET @D = @StartDate
WHILE @D<=@EndDate
	BEGIN
		SET @DateKey = CONVERT(char(8),DATEPART(YY,@D)* 10000 + DATEPART(M,@D)*100 + DATEPART(D,@D))
		INSERT INTO DimDate
			SELECT @DateKey,@D,DATEPART(YY,@D),DATEPART(Q,@D),DATEPART(M,@D),DATENAME(MONTH,@D),
				'FY ' + IIF(DATEPART(Q,@D)>1,
					CONCAT(DATEPART(YY,@D),'-',DATEPART(YY,@D)+1),
					CONCAT(DATEPART(YY,@D)-1,'-',DATEPART(YY,@D))
				),
				IIF(DATEPART(Q,@D)>1,DATEPART(Q,@D)-1,4)
		SET @D = DATEADD(d,1,@D)
	END
SET NOCOUNT OFF


-- Step 3: View the DimDate table

select * from DimDate;
