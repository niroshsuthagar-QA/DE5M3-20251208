/*
QASQLETL Module 2 Lab D
Exercise 03 - Create the relationships between the tables
*/
USE QASQLETLDW;

/*
Step 1:		Add relationships between the dimensions
			- DimGeography to DimCustomer
			- DimGeography to DimReseller
*/ 
ALTER TABLE DimCustomer
	ADD CONSTRAINT FKCustomerGeography
	FOREIGN KEY (SKGeography) REFERENCES DimGeography(SKGeography)
GO

ALTER TABLE DimReseller
	ADD CONSTRAINT FKResellerGeography
	FOREIGN KEY (SKGeography) REFERENCES DimGeography(SKGeography)
GO

/*
Step 2:		Add relationships between the dimensions and fact tables
			- DimCustomer to FactInternetSales
			- DimDate to FactInternetSales (SKDateOrderDate)
			- DimDate to FactInternetSales (SKDateDueDate)
			- DimDate to FactInternetSales (SKDateShipDate)
			- DimProduct to FactInternetSales

			- DimReseller to FactResellerSales
			- DimDate to FactResellerSales (SKDateOrderDate)
			- DimDate to FactResellerSales (SKDateDueDate)
			- DimDate to FactResellerSales (SKDateShipDate)
			- DimProduct to FactResellerSales
*/ 

ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetOrderDate
	FOREIGN KEY (SKDateOrderDate) REFERENCES DimDate(SKDate)

ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetDueDate
	FOREIGN KEY (SKDateDueDate) REFERENCES DimDate(SKDate)

ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetShipDate
	FOREIGN KEY (SKDateShipDate) REFERENCES DimDate(SKDate)

ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetProduct
	FOREIGN KEY (SKProduct) REFERENCES DimProduct(SKProduct)
	
ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetCustomer
	FOREIGN KEY (SKCustomer) REFERENCES DimCustomer(SKCustomer)

ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerOrderDate
	FOREIGN KEY (SKDateOrderDate) REFERENCES DimDate(SKDate)

ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerDueDate
	FOREIGN KEY (SKDateDueDate) REFERENCES DimDate(SKDate)

ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerShipDate
	FOREIGN KEY (SKDateShipDate) REFERENCES DimDate(SKDate)

ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerProduct
	FOREIGN KEY (SKProduct) REFERENCES DimProduct(SKProduct)
	
ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerReseller
	FOREIGN KEY (SKReseller) REFERENCES DimReseller(SKReseller)

