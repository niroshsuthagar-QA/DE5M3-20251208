/*
QASQLETL Module 2 Lab D
Exercise 04 - Add the indexes
*/

USE QASQLETLDW;

/*
Add indexes to the dimensions tables as per the design
*/ 

CREATE INDEX DimProductLookup 
	ON DimProduct(ProductBusinessKey,SCDValidTo,SKProduct)
CREATE INDEX DimCustomerLookup 
	ON DimCustomer(CustomerBusinessKey,SKCustomer)
CREATE INDEX DimCustomerGeography 
	ON DimCustomer(SKGeography)
CREATE INDEX DimResellerLookup 
	ON DimReseller(ResellerBusinessKey,SKReseller)
CREATE INDEX DimTimeLookup 
	ON DimDate(RealDate,SKDate)
CREATE INDEX DimGeographyLookup 
	ON DimGeography(StateProvinceID,City,SKGeography)
CREATE INDEX DimResellerGeography 
	ON DimReseller(SKGeography)
GO

/*
Add indexes to the fact tables as per the design
*/ 

CREATE INDEX FISOrderDate 
	ON FactInternetSales(SKDateOrderDate)
CREATE INDEX FISDueDate 
	ON FactInternetSales(SKDateDueDate)
CREATE INDEX FISShipDate 
	ON FactInternetSales(SKDateShipDate)
CREATE INDEX FISProduct 
	ON FactInternetSales(SKProduct)
CREATE INDEX FISCustomer 
	ON FactInternetSales(SKCustomer)
GO

CREATE INDEX FRSOrderDate 
	ON FactResellerSales(SKDateOrderDate)
CREATE INDEX FRSDueDate 
	ON FactResellerSales(SKDateDueDate)
CREATE INDEX FRSShipDate 
	ON FactResellerSales(SKDateShipDate)
CREATE INDEX FRSProduct 
	ON FactResellerSales(SKProduct)
CREATE INDEX FRSReseller 
	ON FactResellerSales(SKReseller)
GO

