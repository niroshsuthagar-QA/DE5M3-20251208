/*
QASQLETL Module 3 Lab D
Exercise 01 - Create the databases and tables necessary for the Lab
*/

-- Step 1: Create CustomerDB
USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerDB')
begin
	ALTER DATABASE CustomerDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database  CustomerDB;
end

CREATE  Database CustomerDB;
GO
 
-- Step 2: Create the Customers table
USE CustomerDB;
go

CREATE table dbo.Customers
(
	CustomerID int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50),
	TotalSales decimal(5,2)
);
go

-- Step 3: Insert data into the Customers table
INSERT INTO Customers
(Name,city,country,TotalSales)
VALUES
('Fred','London','UK',0),
('Lily','Denver','US',0),
('Reza','Bristol','UK',0)
GO

select * from dbo.Customers;
go

-- Step 4: Create the staging database
if EXISTS (select * from sys.databases where name = 'QAETLStagingDB')
begin
	ALTER DATABASE QAETLStagingDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database QAETLStagingDB;
end

CREATE Database QAETLStagingDB;
GO

-- Step 5: Create table for SCD in the staging database
USE QAETLStagingDB;
go

CREATE schema staging;
go

CREATE table staging.Customers
(
	CustomerID int identity primary key,
	CustomerAlternateID int NULL,
	name varchar(50),
	city varchar(50),
	country varchar(50),
	TotalSales decimal(5,2) NULL
);
go



