/*
QASQLETL Module 6 Lab A
Exercise 03 - Make some changes to the Customers table
*/

-- Step 1: Make some changes to customers
--
USE CustomerDB
go

INSERT INTO Customers
(Name,city,country)
VALUES
('Doris','Perth','AUS'),
('Bob','New York','US')
GO

UPDATE Customers
set city = 'Cardiff' where id = 1
go

DELETE Customers where id=2 or id=3
go

select * from dbo.Customers
go

-- Step 2: Examine the cdc_states table
use QAETLStagingDB;
go

select * from cdc_states;  -- ILEND stands for "Initial Load Ended"; TFEND stands for Trickle Feed Update Ended

