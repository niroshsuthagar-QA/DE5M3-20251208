/*
QASQLETL Module 6 Lab B
Exercise 02 - Make some changes to the Customers table
*/

-- Step 1: View staging.customers table
--
USE QAETLStagingDB;
go

select * from staging.Customers;

-- Step 2: Make some changes to customers
--
USE CustomerDB;
go

UPDATE Customers
set name = 'Freddy' where CustomerID = 1
go

UPDATE Customers
set city = 'Liverpool' where CustomerID = 3

select * from dbo.Customers
go

-- Step 3: View staging.customers table
--
USE QAETLStagingDB
go

select * from staging.Customers;

-- End of Script
