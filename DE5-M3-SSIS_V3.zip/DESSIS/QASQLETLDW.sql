/*
QASQLETL Module 2 Lab B
Exercise 01 - Create the database and partitioning
*/
USE MASTER;
GO

-- Step 0: Drop the database if it exists
if EXISTS (select * from sys.databases where name = 'QASQLETLDW') -- Drop the database if it already exists.
begin
	ALTER DATABASE QASQLETLDW SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database  QASQLETLDW;
end
GO

-- Step 1: Create the QASQLETLDW database
CREATE DATABASE QASQLETLDW ON PRIMARY
	(
	NAME = 'QASQLETLDW_Data',
	FILENAME = 'C:\SQLETLDB\QASQLETLDW_Data.mdf',
	SIZE = 40Mb,
	MAXSIZE = 100Mb,
	FILEGROWTH = 20Mb
	)
LOG ON
	(
	NAME = 'QASQLETLDW_Log',
	FILENAME = 'C:\SQLETLLogs\QASQLETLDW_Log.ldf',
	SIZE = 5Mb,
	MAXSIZE = 30Mb,
	FILEGROWTH = 5Mb
	);	
GO

-- Step 2: Create additional filegroups for the dimensions tables and the fact table
ALTER DATABASE QASQLETLDW ADD FILEGROUP Dimensions;
GO
ALTER DATABASE QASQLETLDW ADD FILEGROUP Facts2020Before;
GO
ALTER DATABASE QASQLETLDW ADD FILEGROUP Facts2021;
GO
ALTER DATABASE QASQLETLDW ADD FILEGROUP Facts2022;
GO

-- Step 3:  Create additional files to the filegroups
ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'DIMFile',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWDim.ndf',
	SIZE = 10mb,
	MAXSIZE = 20mb,
	FILEGROWTH = 5mb
	)
	TO FILEGROUP Dimensions;
GO
ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'Fact2020File',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWFact2020.ndf',
	SIZE = 100mb,
	MAXSIZE = 200mb,
	FILEGROWTH = 50mb
	)
	TO FILEGROUP Facts2020Before;
GO
ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'Fact2021File',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWFact2021.ndf',
	SIZE = 100mb,
	MAXSIZE = 200mb,
	FILEGROWTH = 50mb
	)
	TO FILEGROUP Facts2021;
GO
ALTER DATABASE QASQLETLDW
	ADD FILE 
	(
	NAME = 'Fact2022File',
	FILENAME = 'C:\SQLETLDB\QASQLETLDWFact2022.ndf',
	SIZE = 100mb,
	MAXSIZE = 200mb,
	FILEGROWTH = 50mb
	)
	TO FILEGROUP Facts2022;
GO

/*
QASQLETL Module 2 Lab B
Exercise 02 - Create the database and partitioning
*/
USE QASQLETLDW;
GO

-- Step 1: Create a partition function to split dates based on the values 20210101 and 20220101
CREATE PARTITION FUNCTION DatePartitioningFunction(char(8))
	AS RANGE RIGHT FOR VALUES ('20210101','20220101')
GO

/*Step 2:	Create a partition scheme to use the partition 
			function DatePartitioningFunction and 
			split the tables over the filegroups previously
			created Facts2020Before,Facts2021,Facts2022
*/
CREATE PARTITION SCHEME DatePartitionScheme
	AS PARTITION DatePartitioningFunction
	TO (Facts2020Before,Facts2021,Facts2022)
GO

/*
QASQLETL Module 2 Lab C
Exercise 01 - Create the fact tables
*/
USE QASQLETLDW;
GO

-- Step 1: Create a FactInternetSales table
CREATE TABLE FactInternetSales(
	SalesOrderdetailID int not null,
	SalesOrderID int not null,
	SKDateOrderDate char(8),
	SKDateDueDate char(8),
	SKDateShipDate char(8),
	SKCustomer int,
	SKProduct int,
	OrderQuantity bigint,
	SalesAmount money
) ON DatePartitionScheme(SKDateOrderDate);
GO

-- Step 2: Create a FactResellerSales table
CREATE TABLE FactResellerSales(
	SalesOrderdetailID int not null,
	SalesOrderID int not null,
	SKDateOrderDate char(8),
	SKDateDueDate char(8),
	SKDateShipDate char(8),
	SKReseller int,
	SKProduct int,
	OrderQuantity bigint,
	SalesAmount money
) ON DatePartitionScheme(SKDateOrderDate);
GO

/*
QASQLETL Module 2 Lab D
Exercise 01 - Create the dimension tables
*/
USE QASQLETLDW;
GO

-- Step 1: Create the DimProduct table 
CREATE TABLE DimProduct(
	SKProduct int identity(1,1) primary key,
	ProductBusinessKey int not null,
	ProductName nvarchar(50),
	SubcategoryName nvarchar(50),
	CategoryName nvarchar(50),
	Colour nvarchar(15),
	Style nchar(2),
	Size nvarchar(5),
	ProductLine nchar(2),
	SCDValidFrom datetime default getdate(),
	SCDValidTo datetime default null
) ON Dimensions
GO

-- Step 2: Create the DimGeography table 
CREATE TABLE DimGeography(
	SKGeography int identity(1,1) primary key,
	StateProvinceID int not null,
	City nvarchar(30) not null,
	StateProvinceName nvarchar(50),
	TerritoryName nvarchar(50),
	RegionName nvarchar(50)
) ON Dimensions
GO

-- Step 3: Create the DimCustomer table
CREATE TABLE DimCustomer(
	SKCustomer int identity(1,1) primary key,
	CustomerBusinessKey int not null,
	Title nvarchar(8),
	FirstName nvarchar(50),
	MiddleName nvarchar(50),
	LastName nvarchar(50),
	SKGeography int
) ON Dimensions
GO

-- Step 4:	Create the DimReseller table. 
--			The table has a relationship to the conformed dimension DimGeography.
CREATE TABLE DimReseller(
	SKReseller int identity(1,1) primary key,
	ResellerBusinessKey int not null,
	ResellerName  nvarchar(50),
	ResellerAddress  nvarchar(120),
	SKGeography int
) ON Dimensions
GO

/*
QASQLETL Module 2 Lab D
Exercise 02 - Create the date dimension table
*/
USE QASQLETLDW;
GO

--  Step 1: Create the DimDate table 
CREATE TABLE DimDate(
	SKDate char(8) primary key,
	RealDate date,
	CalendarYear int,
	CalendarQuarter int,
	CalendarMonth int,
	MonthTitle nvarchar(20),
	FiscalYear varchar(20),
	FiscalQuarter int
) ON Dimensions
GO

-- Step 2: Insert rows into the DimTime table
SET NOCOUNT ON
DECLARE @StartDate date, @EndDate date, @D date
DECLARE @DateKey char(10)
SET @StartDate = '2006-01-01'
SET @EndDate = '2025-12-31'
SET @D = @StartDate
WHILE @D<=@EndDate
	BEGIN
		SET @DateKey = CONVERT(char(8),DATEPART(YY,@D)* 10000 + DATEPART(M,@D)*100 + DATEPART(D,@D))
		INSERT INTO DimDate
			SELECT @DateKey,@D,DATEPART(YY,@D),DATEPART(Q,@D),DATEPART(M,@D),DATENAME(MONTH,@D),
				'FY ' + IIF(DATEPART(Q,@D)>1,
					CONCAT(DATEPART(YY,@D),'-',DATEPART(YY,@D)+1),
					CONCAT(DATEPART(YY,@D)-1,'-',DATEPART(YY,@D))
				),
				IIF(DATEPART(Q,@D)>1,DATEPART(Q,@D)-1,4)
		SET @D = DATEADD(d,1,@D)
	END
SET NOCOUNT OFF

/*
QASQLETL Module 2 Lab D
Exercise 03 - Create the relationships between the tables
*/
USE QASQLETLDW;
GO

/*
Step 1:		Add relationships between the dimensions
			- DimGeography to DimCustomer
			- DimGeography to DimReseller
*/ 
ALTER TABLE DimCustomer
	ADD CONSTRAINT FKCustomerGeography
	FOREIGN KEY (SKGeography) REFERENCES DimGeography(SKGeography)
GO
ALTER TABLE DimReseller
	ADD CONSTRAINT FKResellerGeography
	FOREIGN KEY (SKGeography) REFERENCES DimGeography(SKGeography)
GO

/*
Step 2:		Add relationships between the dimensions and fact tables
*/ 
ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetOrderDate
	FOREIGN KEY (SKDateOrderDate) REFERENCES DimDate(SKDate)
ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetDueDate
	FOREIGN KEY (SKDateDueDate) REFERENCES DimDate(SKDate)
ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetShipDate
	FOREIGN KEY (SKDateShipDate) REFERENCES DimDate(SKDate)
ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetProduct
	FOREIGN KEY (SKProduct) REFERENCES DimProduct(SKProduct)
ALTER TABLE FactInternetSales
	ADD CONSTRAINT FKInternetCustomer
	FOREIGN KEY (SKCustomer) REFERENCES DimCustomer(SKCustomer)
ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerOrderDate
	FOREIGN KEY (SKDateOrderDate) REFERENCES DimDate(SKDate)
ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerDueDate
	FOREIGN KEY (SKDateDueDate) REFERENCES DimDate(SKDate)
ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerShipDate
	FOREIGN KEY (SKDateShipDate) REFERENCES DimDate(SKDate)
ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerProduct
	FOREIGN KEY (SKProduct) REFERENCES DimProduct(SKProduct)
ALTER TABLE FactResellerSales
	ADD CONSTRAINT FKResellerReseller
	FOREIGN KEY (SKReseller) REFERENCES DimReseller(SKReseller)

/*
QASQLETL Module 2 Lab D
Exercise 04 - Add the indexes
*/
USE QASQLETLDW;
GO

-- Add indexes to the dimensions tables as per the design
CREATE INDEX DimProductLookup 
	ON DimProduct(ProductBusinessKey,SCDValidTo,SKProduct)
CREATE INDEX DimCustomerLookup 
	ON DimCustomer(CustomerBusinessKey,SKCustomer)
CREATE INDEX DimCustomerGeography 
	ON DimCustomer(SKGeography)
CREATE INDEX DimResellerLookup 
	ON DimReseller(ResellerBusinessKey,SKReseller)
CREATE INDEX DimTimeLookup 
	ON DimDate(RealDate,SKDate)
CREATE INDEX DimGeographyLookup 
	ON DimGeography(StateProvinceID,City,SKGeography)
CREATE INDEX DimResellerGeography 
	ON DimReseller(SKGeography)
GO

-- Add indexes to the fact tables as per the design
CREATE INDEX FISOrderDate 
	ON FactInternetSales(SKDateOrderDate)
CREATE INDEX FISDueDate 
	ON FactInternetSales(SKDateDueDate)
CREATE INDEX FISShipDate 
	ON FactInternetSales(SKDateShipDate)
CREATE INDEX FISProduct 
	ON FactInternetSales(SKProduct)
CREATE INDEX FISCustomer 
	ON FactInternetSales(SKCustomer)
GO

CREATE INDEX FRSOrderDate 
	ON FactResellerSales(SKDateOrderDate)
CREATE INDEX FRSDueDate 
	ON FactResellerSales(SKDateDueDate)
CREATE INDEX FRSShipDate 
	ON FactResellerSales(SKDateShipDate)
CREATE INDEX FRSProduct 
	ON FactResellerSales(SKProduct)
CREATE INDEX FRSReseller 
	ON FactResellerSales(SKReseller)
GO

/*
Show a record count of all the tables
Note: All should be 0 except for DimDate with 7305 records
*/
USE QASQLETLDW;
GO

SELECT 'DimDate' AS TableName, COUNT(*) AS Records FROM DimDate
UNION
SELECT 'DimProduct', COUNT(*) FROM DimProduct
UNION
SELECT 'DimGeography', COUNT(*) FROM DimGeography
UNION
SELECT 'DimCustomer', COUNT(*) FROM DimCustomer
UNION
SELECT 'DimReseller', COUNT(*) FROM DimReseller
UNION
SELECT 'FactInternetSales', COUNT(*) FROM FactInternetSales
UNION
SELECT 'FactResellerSales', COUNT(*) FROM FactResellerSales
GO

-- END of Script