/*
QASQLETL Module 6 Demo on the Change Tracking
*/

-- Step 1: Create CustomerDB

USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerDB')
begin
	ALTER DATABASE CustomerDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database CustomerDB;
end

CREATE  Database CustomerDB;
GO
 
-- Step 2: Create the Customers and ExtractLog tables
USE CustomerDB;
go

CREATE TABLE dbo.Customers
(
	CustomerID int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50)
);
go

CREATE TABLE dbo.ExtractLog
(SourceName varchar(20),
 LastExtractTime datetime,
 LastExtractedVersion int);
GO

-- Step 3: Insert data into the Customers and ExtractLog tables

INSERT INTO Customers
(Name,city,country)
VALUES
('Fred','London','UK'),
('Lily','Denver','US'),
('Reza','Bristol','UK');
GO

select * from dbo.Customers;
go

INSERT INTO dbo.ExtractLog
VALUES
('Customers', dateadd(DAY, -1, getdate()), 0);
GO

select * from dbo.ExtractLog;

-- Step 4: Enable Change Tracking
USE master
GO

ALTER DATABASE CustomerDB
SET CHANGE_TRACKING = ON
	(CHANGE_RETENTION = 7 DAYS, AUTO_CLEANUP = ON);
GO

ALTER DATABASE CustomerDB
SET ALLOW_SNAPSHOT_ISOLATION ON;
GO

USE CustomerDB
GO

ALTER TABLE dbo.Customers
ENABLE CHANGE_TRACKING
WITH (TRACK_COLUMNS_UPDATED = ON);
GO

-- Step 5: Obtain the initial data and log the current version number
DECLARE @current_version BigInt
SET @current_version = CHANGE_TRACKING_CURRENT_VERSION();

UPDATE dbo.ExtractLog
SET LastExtractedVersion = @current_version
WHERE SourceName = 'Customers';
GO

select * from dbo.ExtractLog;

-- Step 6: Insert a new Customer
INSERT INTO Customers
(Name,city,country)
VALUES
('Dinah','Talinn','EE');
GO

-- Step 7: Update a Customer
UPDATE dbo.Customers
	SET city = 'Paris',
	Country='FR'
WHERE CustomerID = 1;
GO

Select * from dbo.Customers;


-- Step 8: Retrieve the changes between the last extracted and current versions
SET TRANSACTION ISOLATION LEVEL SNAPSHOT

DECLARE @previous_version BigInt
SELECT @previous_version = MAX(LastExtractedVersion)
FROM dbo.ExtractLog
WHERE SourceName = 'Customers';

DECLARE @current_version BigInt
SET @current_version = CHANGE_TRACKING_CURRENT_VERSION();
print @current_version;

SELECT  @previous_version 'Previously retrieved Version',
	    @current_version 'Current version',
		CT.CustomerID,
        C.name,
		C.City,
		C.Country
FROM
CHANGETABLE(CHANGES dbo.Customers, @previous_version) as CT
INNER JOIN dbo.Customers as C ON CT.CustomerID = C.CustomerID;

UPDATE dbo.ExtractLog
SET LastExtractedVersion = @current_version
WHERE SourceName = 'Customers';

SET TRANSACTION ISOLATION LEVEL READ COMMITTED
GO

select * from dbo.ExtractLog;