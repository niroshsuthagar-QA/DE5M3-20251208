/*
QASQLETL Module 6 Demo on Temporal tables
*/

-- Step 1: Create CustomerDB

USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerDB')
begin
	ALTER DATABASE CustomerDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database CustomerDB;
end

CREATE  Database CustomerDB;
GO
 
-- Step 2: Create the Customers temporal table
USE CustomerDB;
go

CREATE TABLE dbo.Customers
(
	CustomerID int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50),
	SysStartTime	datetime2 GENERATED ALWAYS AS ROW START NOT NULL,
	SysEndTime		datetime2 GENERATED ALWAYS AS ROW END NOT NULL,
	PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime)
) WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.CustomerHistory));
go


-- Step 3: Insert data into the Customers and ExtractLog tables

INSERT INTO Customers
(Name,city,country)
VALUES
('Fred','London','UK'),
('Lily','Denver','US'),
('Reza','Bristol','UK');
GO

go
;

-- Step 4: Query the customers and customerHistory tables

select * from dbo.Customers;
select * from dbo.CustomerHistory;  -- notice this is empty at the moment

-- Step 5: make some changes to the customer table
UPDATE dbo.Customers
	SET city = 'Paris',
	Country='FR'
WHERE CustomerID = 1;

DELETE dbo.Customers WHERE CustomerID = 2;
GO

-- Step 6: Query the customers and customerHistory tables

select * from dbo.Customers;
select * from dbo.CustomerHistory;  -- notice this now contains the old versions


-- Step 7: Query customers at a point in time. View the result in Object Explorer.

select * from dbo.Customers
FOR SYSTEM_TIME ALL;

-- Step 8: Make some more changes

UPDATE dbo.Customers
	SET city = 'Cardiff'
	WHERE CustomerID = 3;

-- Step 9: Query the customers and customerHistory tables

select * from dbo.Customers;
select * from dbo.CustomerHistory;

-- Step 10: Make another changes

UPDATE dbo.Customers
	SET city = 'Glasgow'
	WHERE CustomerID = 3;

-- Step  11: Query the customers and customerHistory tables

select * from dbo.Customers;
select * from dbo.CustomerHistory;

-- Make a note of the SysEndTime values of the deletion of Customerid 2 and the change 1st change of customerid 3

--  Step 12: Query customers between 2 points in time 

select * from dbo.Customers
FOR SYSTEM_TIME 
BETWEEN '2022-03-10 11:18:21.0421269' and '2022-03-10 11:22:11.9865150'; --change times to the ones recorded in step 11.

GO

-- Step 13: Turn off versioning

ALTER TABLE dbo.Customers SET (SYSTEM_VERSIONING = OFF);

GO
-- Step 14: Refresh Object Explorer.  Notice that CustomerHistory is now a seperate table.

-- Step 15: Empty dbo.CustomersHistory

TRUNCATE TABLE dbo.CustomerHistory;
GO

-- Step 16: Re-enable versioning

ALTER TABLE dbo.Customers
SET (SYSTEM_VERSIONING = ON
 (HISTORY_TABLE = dbo.CustomerHistory,DATA_CONSISTENCY_CHECK=ON)
);


-- Step 17: Refresh Object Explorer and see the result.
