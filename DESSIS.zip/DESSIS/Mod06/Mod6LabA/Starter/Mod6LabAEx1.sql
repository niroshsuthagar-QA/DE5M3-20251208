/*
QASQLETL Module 6 Lab A
Exercise 01 - Create the databases and tables necessary for the Lab
*/

-- Step 1: Create CustomerDB


USE Master
GO

if EXISTS (select * from sys.databases where name = 'CustomerDB')
begin
	ALTER DATABASE CustomerDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database CustomerDB;
end

CREATE  Database CustomerDB;
GO
 
-- Step 2: Create the Customers table
USE CustomerDB;
go

CREATE table dbo.Customers
(
	id int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50)
);
go

-- Step 3: Insert data into the Customers table

INSERT INTO Customers
(Name,city,country)
VALUES
('Fred','London','UK'),
('Lily','Denver','US'),
('Reza','Bristol','UK')
GO

select * from dbo.Customers;
go

-- Step 4: Create the staging database
if EXISTS (select * from sys.databases where name = 'QAETLStagingDB')
begin
	ALTER DATABASE QAETLStagingDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE;
	DROP database QAETLStagingDB;
end

CREATE Database QAETLStagingDB;
GO

-- Step 5: Create tables for incremental customer data in the staging database
USE QAETLStagingDB;
go

CREATE schema staging;
go

CREATE table staging.CustomersINS
(
	id int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50)
);
go

CREATE table staging.CustomersDEL
(
	id int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50)
);
go

CREATE table staging.CustomersUPD
(
	id int identity primary key,
	name varchar(50),
	city varchar(50),
	country varchar(50)
);




