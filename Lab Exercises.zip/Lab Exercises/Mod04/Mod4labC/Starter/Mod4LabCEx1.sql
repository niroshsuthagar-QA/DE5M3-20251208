select P.ProductID, P.Name as ProductName, PC.Name as CategoryName, PSC.Name as SubCategoryName,
		P.Color, P.Style, P.Size,P.ProductLine
from Production.ProductCategory as PC 
inner join Production.ProductSubcategory as PSC
	on PC.ProductCategoryID = PSC.ProductCategoryID
inner join Production.Product as P
	on PSC.ProductSubcategoryID = P.ProductSubcategoryID
order by P.ProductID;