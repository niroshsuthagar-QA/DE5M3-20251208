USE [AdventureWorks]
GO

INSERT INTO [Production].[Product]
           ([Name],[ProductNumber],[MakeFlag],[FinishedGoodsFlag],[Color],[SafetyStockLevel],[ReorderPoint],[StandardCost]
		   ,[ListPrice],[DaysToManufacture],[ProductSubcategoryID],SellStartDate
           )
     VALUES
           (
			'Large Exercise Bike','EB-1235',1,1,'Blue',100,110,150,180,7,1,getdate()
		   )
GO


