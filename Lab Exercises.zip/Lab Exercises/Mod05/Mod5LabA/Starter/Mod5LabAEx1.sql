/*
QASQLETL Module 5 Lab B
Exercise 01 - Create the staging database
*/

-- Step 1: Create QAETLStagingDB


USE Master
GO

-- Step 1: Create the staging database
if EXISTS (select * from sys.databases where name = 'QAETLStagingDB')
begin
	ALTER DATABASE QAETLStagingDB SET  SINGLE_USER WITH  ROLLBACK IMMEDIATE
	DROP database QAETLStagingDB;
end
GO
CREATE Database QAETLStagingDB;
GO

-- Step 2: create the products table

use QAETLStagingDB
go

create schema staging;
go

create table staging.Products
(
	ProductStagingID	int		Primary key identity(1,1),
	productname			varchar(50) NOT NULL,
	Colour				varchar(20) NULL,
	Cost				int			NOT NULL,
	ListPrice			int			NOT NULL,
	changetime			datetime	default(getdate())
);
