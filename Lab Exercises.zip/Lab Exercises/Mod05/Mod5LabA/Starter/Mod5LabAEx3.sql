USE [AdventureWorks]
GO

INSERT INTO [Production].[Product]
           ([Name],[ProductNumber],[MakeFlag],[FinishedGoodsFlag],[Color],[SafetyStockLevel],[ReorderPoint],[StandardCost]
		   ,[ListPrice],[DaysToManufacture],[ProductSubcategoryID],SellStartDate
           )
     VALUES
           (
			'Medium Exercise Bike2','EB-1237',1,1,'Blue',100,110,150,180,7,1,getdate()
		   )
GO


