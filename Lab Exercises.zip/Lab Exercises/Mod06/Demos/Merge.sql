/*
QASQLETL Module 6 Demo on the MERGE statement
*/

USE AdventureWorks;
go

-- Create the People and PeopleStaging tables for the demo

select top 5 BusinessEntityID, FirstName,LastName, EmailPromotion, PersonType 
into dbo.People
from Person.Person;
go

select top 5 BusinessEntityID, FirstName,LastName, EmailPromotion, PersonType 
into dbo.PeopleStaging
from Person.Person;
go

-- View the 2 tables

select * from dbo.People;

select * from dbo.PeopleStaging;

/* Add 2 new entries, make 2 updates and 1 deletion in the staging table */ 

update dbo.PeopleStaging set PersonType = 'SC' where BusinessEntityID = 1;
update dbo.PeopleStaging set EmailPromotion = 1 where BusinessEntityID = 3;

insert dbo.PeopleStaging (BusinessEntityID,FirstName,LastName,EmailPromotion,PersonType)
values (6,'Fred','Smith',0,'EM'),
		(7,'Liz','Jones',1,'SC');

delete dbo.PeopleStaging where BusinessEntityID = 4;

select * from dbo.PeopleStaging;

-- Merge the staging table with the target table

MERGE into dbo.People as Target
USING dbo.PeopleStaging as Source
ON Target.BusinessEntityID = Source.BusinessEntityID
WHEN NOT MATCHED BY TARGET THEN											-- Insert any new rows
	insert (BusinessEntityID,FirstName,LastName,EmailPromotion,PersonType)
	Values (Source.BusinessEntityID,Source.FirstName,Source.LastName,Source.EmailPromotion,Source.PersonType)
WHEN MATCHED THEN														-- Change updated rows
	update set 
				Target.BusinessEntityID = Source.BusinessEntityID,
				Target.FirstName = Source.FirstName,
				Target.LastName = Source.LastName,
				Target.EmailPromotion = Source.EmailPromotion,
				Target.PersonType = Source.PersonType
WHEN NOT MATCHED BY SOURCE THEN											-- Delete old records
				delete;


-- View the people table to see the changes.

select * from dbo.People;

-- Tidy Up.

drop table if EXISTS dbo.People;

drop table IF EXISTS dbo.PeopleStaging;