/*
QASQLETL Module 6 Lab A
Exercise 02 - Enable CDC
*/

-- Step 1:  Check ownership of CustomerDB

USE CustomerDB;
go

IF (select SUSER_SNAME(owner_sid) from sys.databases WHERE NAME='CustomerDB') <> 'sa'
BEGIN
   EXEC sp_changedbowner 'sa'
END
go
 
-- Step 2: If CustomerDB has not already got CDC enabled, then enable CDC for the database

if (select is_cdc_enabled from sys.databases WHERE NAME='CustomerDB') = 'false'
BEGIN
   EXEC sys.sp_cdc_enable_db
END
go
 
-- Step 3: Check dbo.customers is not already CDC enabled, if not then enable CDC for the table
if (select is_tracked_by_cdc from sys.tables WHERE SCHEMA_NAME(schema_id)='dbo' and  NAME = 'Customers') = 'false'
BEGIN
EXEC sys.sp_cdc_enable_table
   @source_schema = N'dbo',
   @source_name   = N'Customers',
   @role_name     = NULL,
   @supports_net_changes = 1
END
